<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       catalog/language/ru-ru/product/search.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Heading
$_['heading_title']     = 'Поиск';
$_['heading_tag']       = 'Тег - ';

// Text
$_['text_search']       = 'Товары, соответствующие критериям поиска';
$_['text_keyword']      = 'Ключевые слова';
$_['text_category']     = 'Все категории';
$_['text_sub_category'] = 'Искать в подкатегориях';
$_['text_empty']        = 'Не найдено товаров, соответствующих критериям поиска.';
$_['text_quantity']     = 'Кол-во:';
$_['text_manufacturer'] = 'Бренд:';
$_['text_model']        = 'Модель:';
$_['text_points']       = 'Бонусные баллы:';
$_['text_price']        = 'Цена:';
$_['text_tax']          = 'Без налога:';
$_['text_reviews']      = 'На основании %s отзыв(а)(ов).';
$_['text_compare']      = 'Сравнение (%s)';
$_['text_sort']         = 'Сортировать по';
$_['text_default']      = 'По умолчанию';
$_['text_name_asc']     = 'Имя (А - Я)';
$_['text_name_desc']    = 'Имя (Я - А)';
$_['text_price_asc']    = 'Цена (по возрастанию)';
$_['text_price_desc']   = 'Цена (по убыванию)';
$_['text_rating_asc']   = 'Рейтинг (от наименьшего)';
$_['text_rating_desc']  = 'Рейтинг (от наивысшего)';
$_['text_model_asc']    = 'Модель (А - Я)';
$_['text_model_desc']   = 'Модель (Я - А)';
$_['text_limit']        = 'Показать по';

// Entry
$_['entry_search']      = 'Критерий поиска';
$_['entry_description'] = 'Искать в описании товаров';
