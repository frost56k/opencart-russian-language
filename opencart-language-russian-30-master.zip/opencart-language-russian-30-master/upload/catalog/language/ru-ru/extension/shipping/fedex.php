<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       catalog/language/ru-ru/extension/shipping/fedex.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Text
$_['text_title']                               = 'Fedex';
$_['text_weight']                              = 'Вес:';
$_['text_eta']                                 = 'Расчетное время:';
$_['text_europe_first_international_priority'] = 'Европейский первый международный приоритет';
$_['text_fedex_1_day_freight']                 = 'FedEx 1 день грузовая';
$_['text_fedex_2_day']                         = 'FedEx 2 дня';
$_['text_fedex_2_day_am']                      = 'FedEx 2 дня утро';
$_['text_fedex_2_day_freight']                 = 'FedEx 2 дня грузовая';
$_['text_fedex_3_day_freight']                 = 'FedEx 3 дня грузовая';
$_['text_fedex_express_saver']                 = 'FedEx эконом экспресс';
$_['text_fedex_first_freight']                 = 'FedEx первая грузовая';
$_['text_fedex_freight_economy']               = 'FedEx грузовая экономом';
$_['text_fedex_freight_priority']              = 'FedEx грузовая приоритетная';
$_['text_fedex_ground']                        = 'FedEx наземная';
$_['text_first_overnight']                     = 'Первая вечер';
$_['text_ground_home_delivery']                = 'Наземная доставка на дом';
$_['text_international_economy']               = 'Международная экономом';
$_['text_international_economy_freight']       = 'Международная экономом грузовая';
$_['text_international_first']                 = 'Международная первая';
$_['text_international_priority']              = 'Международная приоритетная';
$_['text_international_priority_freight']      = 'Международная приоритетная грузовая';
$_['text_priority_overnight']                  = 'Приоритетная вечер';
$_['text_smart_post']                          = 'Умная почта';
$_['text_standard_overnight']                  = 'Стандартная вечер';
