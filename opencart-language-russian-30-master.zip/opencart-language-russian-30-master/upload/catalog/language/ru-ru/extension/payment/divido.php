<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       catalog/language/ru-ru/extension/payment/divido.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

$_['text_checkout_title']      = 'Оплата в рассрочку';
$_['text_choose_plan']         = 'Выбери свой тариф';
$_['text_choose_deposit']      = 'Выберите свой депозит';
$_['text_monthly_payments']    = 'ежемесячные выплаты';
$_['text_months']              = 'месяцы';
$_['text_term']                = 'Срок';
$_['text_deposit']             = 'Депозит';
$_['text_credit_amount']       = 'Стоимость кредита';
$_['text_amount_payable']      = 'Итого к оплате';
$_['text_total_interest']      = 'Общая процентная ставка годовых';
$_['text_monthly_installment'] = 'Ежемесячный взнос';
$_['text_redirection']         = 'Вы будете перенаправлены на Divido для заполнения этой финансовой заявки, когда подтвердите свой заказ.';
$_['divido_checkout']          = 'Подтвердить и оформить заказ с Divido';
$_['deposit_to_low']           = 'Депозит мал';
$_['credit_amount_to_low']     = 'Сумма кредита слишком мала';
$_['no_country']               = 'Страна не принята';
$_['text_divido']              = 'Divido';
