<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       admin/language/ru-ru/catalog/review.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Heading
$_['heading_title']     = 'Отзывы';

// Text
$_['text_success']      = 'Успешно: Вы изменили отзывы!';
$_['text_list']         = 'Список отзывов';
$_['text_add']          = 'Добавить отзыв';
$_['text_edit']         = 'Редактировать отзыв';
$_['text_filter']       = 'Фильтр';

// Column
$_['column_product']    = 'Товар';
$_['column_author']     = 'Автор';
$_['column_rating']     = 'Рейтинг';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата добавления';
$_['column_action']     = 'Действие';

// Entry
$_['entry_product']     = 'Товар';
$_['entry_author']      = 'Автор';
$_['entry_rating']      = 'Рейтинг';
$_['entry_status']      = 'Статус';
$_['entry_text']        = 'Текст';
$_['entry_date_added']  = 'Дата добавления';

// Help
$_['help_product']      = '(Автодополнение)';

// Error
$_['error_permission']  = 'Предупреждение: У вас нет разрешения на изменение отзывов!';
$_['error_product']     = 'Товар обязателен!';
$_['error_author']      = 'Автор должен быть от 3 до 64 символов!';
$_['error_text']        = 'Текст отзыва должен быть не менее 1 символа!';
$_['error_rating']      = 'Рейтинг отзыва обязателен!';
