<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       admin/language/ru-ru/extension/payment/payza.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Heading
$_['heading_title']      = 'Payza';

// Text
$_['text_extension']     = 'Расширения';
$_['text_success']       = 'Успешно: Вы изменили детали учетной записи Payza!';
$_['text_edit']          = 'Редактировать Payza';

// Entry
$_['entry_merchant']     = 'Идентификатор продавца';
$_['entry_security']     = 'Код безопасности';
$_['entry_callback']     = 'URL тревоги';
$_['entry_total']        = 'Всего';
$_['entry_order_status'] = 'Статус заказа';
$_['entry_geo_zone']     = 'Геозона';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Порядок сортировки';

// Help
$_['help_callback']      = 'Это должно быть установлено в панели управления Payza. вам также нужно будет проверить «IPN статус» для включения.';
$_['help_total']         = 'Общая сумма, которую должен достичь заказ, прежде чем этот метод оплаты станет активным.';

// Error
$_['error_permission']   = 'Предупреждение: У вас нет разрешения на изменение payment Payza!';
$_['error_merchant']     = 'Идентификатор продавца обязателен!';
$_['error_security']     = 'Код безопасности обязателен!';
