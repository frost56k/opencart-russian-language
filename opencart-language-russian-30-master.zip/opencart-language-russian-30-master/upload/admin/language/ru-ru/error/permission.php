<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       admin/language/ru-ru/error/permission.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Heading
$_['heading_title']   = 'Доступ запрещен!';

// Text
$_['text_permission'] = 'У вас нет прав доступа к этой странице, обратитесь к вашему системному администратору.';
