<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       admin/language/ru-ru/common/dashboard.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Heading
$_['heading_title'] = 'Инфо панель';

// Error
$_['error_install'] = 'Предупреждение: Папка установки все еще существует и должна быть удалена из соображений безопасности!';
