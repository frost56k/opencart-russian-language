<?php
/**
 * @package    Русский язык для OpenCart 3.x
 * @file       install/language/ru-ru/ru-ru.php
 * @author     Hkr32
 * @copyright  © OCN, (https://opencart.name)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       https://forum.opencart.name
 */

// Button
$_['button_continue'] = 'Продолжить';
$_['button_back']     = 'Назад';

// Error
$_['error_exception'] = 'Код ошибки(%s): %s в %s строка %s';
